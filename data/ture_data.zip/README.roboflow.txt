
finger2 - v1 2022-06-15 4:59pm
==============================

This dataset was exported via roboflow.ai on June 15, 2022 at 9:00 AM GMT

It includes 498 images.
Number are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


